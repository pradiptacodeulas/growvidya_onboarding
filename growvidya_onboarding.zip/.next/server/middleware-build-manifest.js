globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/k1lW48rrlKxQDNBWuL0bC/_buildManifest.js",
    "static/k1lW48rrlKxQDNBWuL0bC/_ssgManifest.js",
    "static/k1lW48rrlKxQDNBWuL0bC/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3ezhpn0kv-g9m.js",
    "static/chunks/435otz09cyq_7.js",
    "static/chunks/2lm6ee1ot3_cu.js",
    "static/chunks/turbopack-3haiakwn64v4p.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
