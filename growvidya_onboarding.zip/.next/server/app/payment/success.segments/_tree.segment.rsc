:HL["/_next/static/chunks/0fxi_h-xzasxo.css","style"]
:HL["/_next/static/chunks/1i5hacn-mo6kg.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"payment","param":null,"prefetchHints":4192,"slots":{"children":{"name":"success","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}}}},"staleTime":300,"buildId":"k1lW48rrlKxQDNBWuL0bC"}
